import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { updateUserPreferences } from '../firebase/firestore'
import AppLayout from '../components/layout/AppLayout'
import { Settings as SettingsIcon, Check, DollarSign, User } from 'lucide-react'
import clsx from 'clsx'

const CURRENCIES = ['€', '$', '£', '₿', 'CHF', 'CAD']
const WEEK_STARTS = [{ value: 'monday', label: 'Lundi' }, { value: 'saturday', label: 'Samedi' }]

export default function Settings() {
  const { user, userData } = useAuth()
  const prefs = userData?.preferences || {}
  const [currency,  setCurrency]  = useState(prefs.currency  || '€')
  const [weekStart, setWeekStart] = useState(prefs.weekStart || 'monday')
  const [saving,    setSaving]    = useState(false)
  const [saved,     setSaved]     = useState(false)

  const handleSave = async () => {
    setSaving(true)
    await updateUserPreferences(user.uid, { ...prefs, currency, weekStart })
    setSaving(false); setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const btnClass = (active) => clsx(
    'px-4 py-2 rounded-xl text-sm font-medium border transition-all',
    active ? 'bg-brand-500/15 border-brand-500/30 text-brand-600 dark:text-brand-400' : 'bg-surface-muted border-surface-border text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
  )

  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-2xl mx-auto space-y-6 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-zinc-900 dark:text-white">Paramètres</h1>
          <p className="text-zinc-500 text-sm mt-0.5">Personnalise ton expérience</p>
        </div>
        <Section icon={User} title="Profil">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center text-brand-600 dark:text-brand-400 font-bold text-xl">
              {(userData?.displayName || user?.displayName || 'U')[0].toUpperCase()}
            </div>
            <div>
              <p className="font-semibold text-zinc-900 dark:text-white">{userData?.displayName || user?.displayName}</p>
              <p className="text-sm text-zinc-500">{user?.email}</p>
            </div>
          </div>
        </Section>
        <Section icon={DollarSign} title="Devise">
          <div className="flex flex-wrap gap-2">
            {CURRENCIES.map(c => <button key={c} onClick={() => setCurrency(c)} className={clsx(btnClass(currency === c), 'font-mono')}>{c}</button>)}
          </div>
        </Section>
        <Section icon={SettingsIcon} title="Début du weekend">
          <div className="flex gap-2">
            {WEEK_STARTS.map(ws => <button key={ws.value} onClick={() => setWeekStart(ws.value)} className={btnClass(weekStart === ws.value)}>{ws.label}</button>)}
          </div>
        </Section>
        <button onClick={handleSave} disabled={saving}
          className={clsx('flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-sm transition-all',
            saved ? 'bg-brand-500/20 text-brand-600 dark:text-brand-400 border border-brand-500/30' : 'bg-brand-500 hover:bg-brand-400 text-white shadow-lg shadow-brand-500/25')}>
          {saved ? <><Check size={16} /> Enregistré !</> : saving ? 'Enregistrement…' : 'Sauvegarder'}
        </button>
      </div>
    </AppLayout>
  )
}

function Section({ icon: Icon, title, children }) {
  return (
    <div className="bg-surface-card border border-surface-border rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Icon size={15} className="text-zinc-400" />
        <h2 className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">{title}</h2>
      </div>
      {children}
    </div>
  )
}
